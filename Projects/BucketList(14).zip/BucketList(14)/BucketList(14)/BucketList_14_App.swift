//
//  BucketList_14_App.swift
//  BucketList(14)
//
//  Created by Kyle Sarygin on 9/3/23.
//

import SwiftUI

@main
struct BucketList_14_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
